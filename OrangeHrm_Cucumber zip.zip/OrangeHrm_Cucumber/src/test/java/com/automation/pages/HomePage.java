package com.automation.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePage extends BasePage{
    @FindBy(xpath = "(//span[@class='oxd-text oxd-text--span oxd-main-menu-item--name'])[1]")
    WebElement adminMenu;
    @FindBy(xpath = "//span[normalize-space()='Recruitment']")
    WebElement recruitementMenu;


    public void clickOnAdminMenu(){
        adminMenu.click();
    }
    public void clickOnRecruitmentMenu(){
        recruitementMenu.click();
    }
}
