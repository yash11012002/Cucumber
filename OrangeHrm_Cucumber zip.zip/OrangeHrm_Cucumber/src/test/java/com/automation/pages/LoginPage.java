package com.automation.pages;

import com.automation.utils.DriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage extends BasePage {
    @FindBy(xpath = "//input[@placeholder=\"Username\"]")
    WebElement usernameInput;
    @FindBy(xpath = "//input[@name=\"password\"]")
    WebElement passwordInput;
    @FindBy(xpath = "//button[@type=\"submit\"]")
    WebElement loginBtn;


    public void openWebsite(){
       driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
    }

    public void doLogin(){
        usernameInput.sendKeys("Admin");
        passwordInput.sendKeys("admin123");
        loginBtn.click();
    }

}
