package com.automation.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.Random;

public class RecruitmentPage extends BasePage {

    @FindBy(xpath = "//button[@class=\"oxd-button oxd-button--medium oxd-button--secondary\"]")
    WebElement addBtn;

    @FindBy(xpath = "(//div[@class='oxd-grid-item oxd-grid-item--gutters'])[1]//div[@class='oxd-select-text-input']")
    WebElement adminroleEntry;
    @FindBy(xpath = "(//div[@class='oxd-select-option'])[2]")
    WebElement adminEss;
    @FindBy(xpath = "//input[@placeholder=\"Type for hints...\"]")
    WebElement employeerName;
    @FindBy(xpath = "//div[@class=\"oxd-autocomplete-dropdown --positon-bottom\"]")
    WebElement jamesDropDDown;
    @FindBy(xpath = "//div[@class='oxd-form-row']//div[@class='oxd-grid-2 orangehrm-full-width-grid']//div[@class='oxd-grid-item oxd-grid-item--gutters']//div[@class='oxd-input-group oxd-input-field-bottom-space']//div//input[@class='oxd-input oxd-input--active']")
    WebElement usernameInputnew;
    @FindBy(xpath = "//div[@class=\"oxd-form-row user-password-row\"]//div[@class=\"oxd-grid-2 orangehrm-full-width-grid\"]//div[@class=\"oxd-grid-item oxd-grid-item--gutters user-password-cell\"]//div[@class=\"oxd-input-group oxd-input-field-bottom-space\"]//input[@type=\"password\"]")
    WebElement passwordInputnew;
    @FindBy(xpath = "//div[@class='oxd-grid-item oxd-grid-item--gutters']//div[@class='oxd-input-group oxd-input-field-bottom-space']//div//input[@type='password']")
    WebElement confirmPassword;
    @FindBy(xpath = "//button[@type=\"submit\"]")
    WebElement saveBtn;
    @FindBy(xpath = "//div[@class=\"oxd-select-text-input\" and normalize-space(text()) = '-- Select --']")
    WebElement statusInput;
    @FindBy(xpath = "//div[@class=\"oxd-select-option\"][2]")
    WebElement enabledDropdown;
    @FindBy(xpath = "//button[@class=\"oxd-button oxd-button--medium oxd-button--secondary orangehrm-left-space\"]")
    WebElement saveOnAdminPage;



    public void clickOnAddUser(){
        addBtn.click();
    }
    public void setRoleEss(){
        adminroleEntry.click();
        adminEss.click();
    }

    public void setEmployeeName()  {
        employeerName.sendKeys("J");
        jamesDropDDown.click();

    }


    public static String generateRandomPassword(){
        String pwdCharacters="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()";
        StringBuilder password=new StringBuilder();
        Random random = new Random();

        int passwordLength=8;

        for(int i=0;i<passwordLength;i++){
            int index=random.nextInt(pwdCharacters.length());
            password.append(pwdCharacters.charAt(index));
        }
        return password.toString();

    }
    public void setRandomUsername(){
        usernameInputnew.click();
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder username = new StringBuilder();
        Random random = new Random();

        // Define the desired username length (e.g., 8 characters)
        int usernameLength = 8;

        for (int i = 0; i < usernameLength; i++) {
            int index = random.nextInt(characters.length());
            username.append(characters.charAt(index));
        }

        String randomUsername = username+"1";
        usernameInputnew.sendKeys(randomUsername);
    }
    public void clickOnSaveBtn(){
        saveBtn.click();
    }
    public void setStatusInput(){
        statusInput.click();
        enabledDropdown.click();
    }
    public void setRandomPassword(){
        String randomPassword=generateRandomPassword()+"1@a";
        passwordInputnew.sendKeys(randomPassword);
        confirmPassword.sendKeys(randomPassword);
    }

    public void clickOnMainSaveBtn(){
        saveOnAdminPage.click();
    }

}
