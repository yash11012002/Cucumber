package com.automation.steps;
import com.automation.pages.HomePage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.testng.reporters.HtmlHelper;

public class HomeSteps {
    HomePage homePage=new HomePage();

    @Then("user click on recruitment link")
    public void userClickOnRecruitmentLink() {
        homePage.clickOnRecruitmentMenu();
    }
}
