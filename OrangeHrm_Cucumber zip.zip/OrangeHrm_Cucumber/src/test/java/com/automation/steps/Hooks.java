package com.automation.steps;

import com.automation.utils.DriverManager;
import org.junit.After;
import org.junit.Before;

public class Hooks {

    @Before
    public void setUp(){
        DriverManager.createDriver();

    }
    @After
    public void cleanUp(){
        DriverManager.getDriver().quit();
    }
}
