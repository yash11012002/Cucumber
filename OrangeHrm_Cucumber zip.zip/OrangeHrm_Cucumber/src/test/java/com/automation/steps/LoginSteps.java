package com.automation.steps;
import com.automation.pages.LoginPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.Given;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LoginSteps {

  //  private static final Logger log = LoggerFactory.getLogger(LoginSteps.class);
    LoginPage loginPage=new LoginPage();

    @Given("user open website")
    public void user_open_website() {
    loginPage.openWebsite();
    }

    @Then("user login to website")
    public void user_login_to_website() {
    loginPage.doLogin();
    }

}
