package com.automation.steps;
import com.automation.pages.RecruitmentPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class RecruitmentSteps {

    RecruitmentPage recruitmentPage=new RecruitmentPage();

    @When("user click on add button")
    public void user_click_on_add_button() {
        recruitmentPage.clickOnAddUser();
    }

    @Then("select role- ESS")
    public void select_role_ess() {
    recruitmentPage.setRoleEss();
    }

    @Then("select employee name- James Butler")
    public void select_employee_name_james_butler() {
        recruitmentPage.setEmployeeName();
    }

    @Then("status enable")
    public void status_enable() {
        recruitmentPage.setStatusInput();
    }

    @Then("generate username randomly")
    public void generate_username_randomly() {
    recruitmentPage.setRandomUsername();
    }
    @Then("click on save button")
    public void clickOnSaveButton() {
        recruitmentPage.clickOnSaveBtn();
    }

    @When("generate password randomly")
    public void generate_password_randomly() {
        recruitmentPage.setRandomPassword();
    }

    @Then("click on mainSave button")
    public void click_on_mainSave_button() {
    recruitmentPage.clickOnMainSaveBtn();
    }


}
